/* Author: Adam Conger
 * Version: 1.0
 * Goal: To display morse code messages of SOS and OK. Upon button press, the
 * message will finish and alternate to the opposite message.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/*Timer include*/
#include <ti/drivers/Timer.h>

volatile unsigned char timerFlag = 0;
volatile unsigned char okFlag = 0;

/*timer callback*/
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    sm_init();
    timerFlag++;
}

/*timer setup*/
void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 * ========= SM function =======
 *
 */
enum boardStates {boardStart, boardLEDSOS, boardLEDOK, rest} boardState;

void sm_init() {

    switch ( boardState ) { //state transitions
    case boardStart:
        if (okFlag == 0) {
            boardState = boardLEDSOS;
        }
        if (okFlag == 1) {
            boardState = boardLEDOK;
        }
        break;
    case boardLEDSOS:
        if (timerFlag == 28) {
            boardState = rest;
            timerFlag = 0;
        }
        break;
    case boardLEDOK:
        if (timerFlag == 23) {
            boardState = rest;
            timerFlag = 0;
        }
        break;
    case rest:
        if (timerFlag == 8) {
            boardState = boardStart;
            timerFlag = 0;
        }
        break;
    default:
        boardState = boardStart;
        break;
    }

    switch (boardState) { // State actions
        case boardLEDSOS:
            /* S */
            if (timerFlag == 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 2) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 3) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 4) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 5) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 6) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }

            /* O */
            if (timerFlag == 9) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 12) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 13) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 16) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 17) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 20) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }

            /* S */
            if (timerFlag == 23) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 24) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 25) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 26) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 27) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            break;
        case boardLEDOK:
            /* O */
            if (timerFlag == 1) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 4) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 5) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 8) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 9) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 12) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }

            /* K */
            if (timerFlag == 15) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            if (timerFlag == 18) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
            if (timerFlag == 19) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON); //Red LED turns on for dot
            }
            if (timerFlag == 20) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);//Red LED turns off
            }
            if (timerFlag == 21) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            }
            break;
        case rest:
            if (timerFlag == 1) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
        default:
            break;
    }
}
/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* Swap message */
    if (boardState == boardLEDSOS) {
        okFlag = 1;
    }
    else if (boardState == boardLEDOK) {
        okFlag = 0;
    }
}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* Swap message */
     if (boardState == boardLEDSOS) {
         okFlag = 1;
     }
     else if (boardState == boardLEDOK) {
         okFlag = 0;
     }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    boardState = boardStart;
    initTimer();

    return (NULL);
}

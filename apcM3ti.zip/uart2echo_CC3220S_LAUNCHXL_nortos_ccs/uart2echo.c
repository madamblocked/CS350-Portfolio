/*
 * Author: Adam Conger
 * Version: 1
 * Date: July 16, 2022
 */

/*
 *  ======== uart2echo.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART2.h>

/* Driver configuration */
#include "ti_drivers_config.h"

/*
 * ========= SM function =======
 *
 */
enum boardStates { boardStart, boardContinue, boardContinue2, boardLEDOn, boardLEDOff } boardState;

void sm_init(char input) {

    switch ( boardState ) { //state transitions
    case boardStart:
        boardState = boardLEDOff;
        break;
    case boardLEDOff:
        if (input == 'o' || input == 'O') {
            boardState = boardContinue;
        }
        break;
    case boardContinue:
        if (input == 'n' || input == 'N') {
            boardState = boardLEDOn;
        }
        else if (input == 'f' || input == 'F') {
            boardState = boardContinue2;
            }
        break;
    case boardContinue2:
        if (input == 'f' || input == 'F') {
            boardState = boardLEDOff;
        }
        break;
    case boardLEDOn:
        if (input == 'o' || input == 'O') {
            boardState = boardContinue;
        }
        break;
    default:
        boardState = boardStart;
        break;
    }

    switch (boardState) { // State actions
        case boardLEDOff:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            break;
        case boardLEDOn:
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            break;
        default:
            break;
    }
}


/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char         input;
    const char   echoPrompt[] = "Echoing characters:\r\n";
    UART2_Handle uart;
    UART2_Params uartParams;
    size_t       bytesRead;
    size_t       bytesWritten = 0;
    uint32_t     status = UART2_STATUS_SUCCESS;

    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART where the default read and write mode is BLOCKING */
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;

    uart = UART2_open(CONFIG_UART2_0, &uartParams);

    if (uart == NULL) {
        /* UART2_open() failed */
        while (1);
    }

    /* Turn on user LED to indicate successful initialization
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);*/

    UART2_write(uart, echoPrompt, sizeof(echoPrompt), &bytesWritten);

    /* Loop forever echoing */
    while (1) {
        bytesRead = 0;
        while (bytesRead == 0) {
            status = UART2_read(uart, &input, 1, &bytesRead);

            if (status != UART2_STATUS_SUCCESS) {
                /* UART2_read() failed */
                 while (1);
            }
        }
        sm_init(input);


        bytesWritten = 0;
        while (bytesWritten == 0) {
            status = UART2_write(uart, &input, 1, &bytesWritten);

            if (status != UART2_STATUS_SUCCESS) {
                /* UART2_write() failed */
                while (1);
            }
        }
    }
}
